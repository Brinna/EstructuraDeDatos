#include "StdAfx.h"
#include "cuentaahorro.h"


cuentaahorro::cuentaahorro(string nom, string cuen, double sal, double cantidad){}
void cuentaahorro::Set_CuotaManten(double cantidad)
{cuotamantenimiento=cantidad;}
double cuentaahorro::Get_CoutaManten()
{return cuotamantenimiento;}
void cuentaahorro::retirar(double cantidad)
{saldo=saldo-cantidad;}