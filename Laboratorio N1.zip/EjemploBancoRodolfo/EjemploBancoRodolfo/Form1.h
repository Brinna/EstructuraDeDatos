#pragma once
#include <iostream>
#include "cuenta.h"
#include "cuentaahorro.h"
#include "msclr\marshal_cppstd.h"

namespace EjemploBancoRodolfo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txtnom;
	private: System::Windows::Forms::TextBox^  txtcuen;
	private: System::Windows::Forms::TextBox^  txtcant;
	private: System::Windows::Forms::TextBox^  txtsal;
	private: System::Windows::Forms::Button^  btning;
	private: System::Windows::Forms::Button^  btnret;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtnom = (gcnew System::Windows::Forms::TextBox());
			this->txtcuen = (gcnew System::Windows::Forms::TextBox());
			this->txtcant = (gcnew System::Windows::Forms::TextBox());
			this->txtsal = (gcnew System::Windows::Forms::TextBox());
			this->btning = (gcnew System::Windows::Forms::Button());
			this->btnret = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(36, 55);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(47, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Nombre:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(36, 119);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(52, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Cantidad:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(36, 148);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(40, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Saldo: ";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(36, 82);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(44, 13);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Cuenta:";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(99, 163);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(0, 13);
			this->label5->TabIndex = 4;
			// 
			// txtnom
			// 
			this->txtnom->Location = System::Drawing::Point(155, 55);
			this->txtnom->Name = L"txtnom";
			this->txtnom->Size = System::Drawing::Size(100, 20);
			this->txtnom->TabIndex = 5;
			// 
			// txtcuen
			// 
			this->txtcuen->Location = System::Drawing::Point(155, 82);
			this->txtcuen->Name = L"txtcuen";
			this->txtcuen->Size = System::Drawing::Size(100, 20);
			this->txtcuen->TabIndex = 6;
			// 
			// txtcant
			// 
			this->txtcant->Location = System::Drawing::Point(155, 111);
			this->txtcant->Name = L"txtcant";
			this->txtcant->Size = System::Drawing::Size(100, 20);
			this->txtcant->TabIndex = 7;
			// 
			// txtsal
			// 
			this->txtsal->Location = System::Drawing::Point(155, 140);
			this->txtsal->Name = L"txtsal";
			this->txtsal->Size = System::Drawing::Size(100, 20);
			this->txtsal->TabIndex = 8;
			// 
			// btning
			// 
			this->btning->Location = System::Drawing::Point(72, 217);
			this->btning->Name = L"btning";
			this->btning->Size = System::Drawing::Size(75, 23);
			this->btning->TabIndex = 9;
			this->btning->Text = L"Ingresar";
			this->btning->UseVisualStyleBackColor = true;
			this->btning->Click += gcnew System::EventHandler(this, &Form1::btning_Click);
			// 
			// btnret
			// 
			this->btnret->Location = System::Drawing::Point(183, 217);
			this->btnret->Name = L"btnret";
			this->btnret->Size = System::Drawing::Size(75, 23);
			this->btnret->TabIndex = 10;
			this->btnret->Text = L"Retirar";
			this->btnret->UseVisualStyleBackColor = true;
			this->btnret->Click += gcnew System::EventHandler(this, &Form1::btnret_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(349, 302);
			this->Controls->Add(this->btnret);
			this->Controls->Add(this->btning);
			this->Controls->Add(this->txtsal);
			this->Controls->Add(this->txtcant);
			this->Controls->Add(this->txtcuen);
			this->Controls->Add(this->txtnom);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
		
			 }
private: System::Void btning_Click(System::Object^  sender, System::EventArgs^  e) {
			string nombre, cuenta;
			double saldo,cantidad;
			nombre = marshal_as<std::string>(System::Convert::ToString(txtnom->Text));
			cuenta = marshal_as<std::string>(System::Convert::ToString(txtcuen->Text));
			saldo = System::Convert::ToDouble(txtsal->Text);
			cantidad = System::Convert::ToDouble(txtcant->Text);
			cuentaahorro cuentita(nombre,cuenta,saldo,1.0);
			cuentita.ingresar(cantidad);
			
		 }
private: System::Void btnret_Click(System::Object^  sender, System::EventArgs^  e) {
			 string nombre, cuenta;
			double saldo,cantidad;
			nombre = marshal_as<std::string>(System::Convert::ToString(txtnom->Text));
			cuenta = marshal_as<std::string>(System::Convert::ToString(txtcuen->Text));
			saldo = System::Convert::ToDouble(txtsal->Text);
			cantidad = System::Convert::ToDouble(txtcant->Text);
			cuentaahorro cuentita(nombre,cuenta,saldo,1.0);
			cuentita.retirar(cantidad);
		 }
};
}

