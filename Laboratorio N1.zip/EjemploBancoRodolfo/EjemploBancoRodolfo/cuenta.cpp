#include "StdAfx.h"
#include "cuenta.h"


cuenta::cuenta(void){}
void cuenta::Set_Nombre(string nom)
{nombre=nom;}
void cuenta::Set_Cuenta(string cuen)
{cuentaa=cuen;}
void cuenta::Set_Saldo(double sal)
{saldo=sal;}
string cuenta::Get_Nombre()
{return nombre;}
string cuenta::Get_Cuenta()
{return cuentaa;}
double cuenta::Get_Saldo()
{return saldo;}
void cuenta::ingresar(double cantidad)
{saldo=saldo+cantidad;}
void cuenta::retirar(double cantidad)
{saldo=saldo-cantidad;}
	