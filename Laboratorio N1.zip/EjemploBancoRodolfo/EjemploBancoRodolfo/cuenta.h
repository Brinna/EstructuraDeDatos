#pragma once
#include <iostream>
#include <string.h>

using namespace std;
class cuenta
{

protected: 
	string nombre;
	string cuentaa;
	double saldo;
public:
	cuenta();
	void Set_Nombre(string nom);
	void Set_Cuenta(string cuen);
	void Set_Saldo(double sal);
	string Get_Nombre();
	string Get_Cuenta();
	double Get_Saldo();
	void ingresar(double cantidad);
	void retirar(double cantidad);
	
};

