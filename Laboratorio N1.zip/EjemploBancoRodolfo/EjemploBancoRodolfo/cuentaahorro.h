#pragma once
#include "cuenta.h"
class cuentaahorro:public cuenta
{
private:
	double cuotamantenimiento;
public:
	cuentaahorro(string nom, string cuen, double sal, double cantidad);
	void Set_CuotaManten(double cantidad);
	double Get_CoutaManten();
	void retirar(double cantidad);
};

