#include "StdAfx.h"
#include "Nodo.h"


Nodo::Nodo(void)
{
}
void Nodo::set_n(string x)
{
	nombre=x;
}
void Nodo::set_c(int x)
{
	ci=x;
}
string Nodo::get_n()
{
	return nombre;
}
int Nodo::get_c()
{
	return ci;
}

