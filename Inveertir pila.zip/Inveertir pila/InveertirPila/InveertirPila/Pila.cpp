#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
	top=-1;
}
void Pila::push(Nodo x)
{
	P[++top]=x;
}
Nodo Pila::pop()
{
	return P[top--];
}
bool Pila::full()
{
	if(top==N-1)
		return true;
	else
		return false;
}
bool Pila::empty()
{
	if(top==-1)
		return true;
	else
		return false;
}
Nodo Pila::peek()
{
	return P[top];
}