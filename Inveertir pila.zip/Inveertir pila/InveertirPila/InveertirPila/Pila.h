#pragma once
#include "Nodo.h"
#define N 25

class Pila: public Nodo
{
private:
	int top;
	Nodo P[N];
public:
	Pila(void);
	void push(Nodo x);
	Nodo pop();
	bool full();
	bool empty();
	Nodo peek();
};

