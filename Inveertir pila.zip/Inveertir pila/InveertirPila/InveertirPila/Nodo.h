#pragma once
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;
class Nodo
{
private:
	string nombre;
	int ci;
public:
	Nodo(void);
	void set_n(string x);
	void set_c(int x);
	string get_n();
	int get_c();

};

