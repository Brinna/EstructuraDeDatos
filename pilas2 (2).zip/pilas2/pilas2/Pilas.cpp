#include "StdAfx.h"
#include "Pilas.h"


Pilas::Pilas(void)
{cima=-1;
V[N]=0;
}

void Pilas::apilar (int x)
{
V[++cima]=x;

}
int Pilas::desapilar()
{int x= V[cima--];
return x;
}
bool Pilas::vacio()
{if (cima==-1)
return true;
}
bool Pilas::lleno()
{if (cima>=N)
return true;
}