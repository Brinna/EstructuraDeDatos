#pragma once
#include "Pilas.h"

namespace pilas2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	
	 Pilas A;
	 int tam=0;
	
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 

	protected: 

	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btnapilar;
	private: System::Windows::Forms::Button^  btndesapilar;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::DataGridView^  grid1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btnapilar = (gcnew System::Windows::Forms::Button());
			this->btndesapilar = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(113, 22);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(30, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"PILA";
			this->label1->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(34, 127);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(0, 13);
			this->label2->TabIndex = 1;
			// 
			// btnapilar
			// 
			this->btnapilar->Location = System::Drawing::Point(197, 54);
			this->btnapilar->Name = L"btnapilar";
			this->btnapilar->Size = System::Drawing::Size(75, 23);
			this->btnapilar->TabIndex = 2;
			this->btnapilar->Text = L"APILAR";
			this->btnapilar->UseVisualStyleBackColor = true;
			this->btnapilar->Click += gcnew System::EventHandler(this, &Form1::btnapilar_Click);
			// 
			// btndesapilar
			// 
			this->btndesapilar->Location = System::Drawing::Point(197, 99);
			this->btndesapilar->Name = L"btndesapilar";
			this->btndesapilar->Size = System::Drawing::Size(75, 23);
			this->btndesapilar->TabIndex = 3;
			this->btndesapilar->Text = L"DESAPILAR";
			this->btndesapilar->UseVisualStyleBackColor = true;
			this->btndesapilar->Click += gcnew System::EventHandler(this, &Form1::btndesapilar_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(37, 56);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 20);
			this->textBox1->TabIndex = 4;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(37, 99);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 20);
			this->textBox2->TabIndex = 5;
			// 
			// grid1
			// 
			this->grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grid1->Location = System::Drawing::Point(56, 162);
			this->grid1->Name = L"grid1";
			this->grid1->Size = System::Drawing::Size(182, 150);
			this->grid1->TabIndex = 6;
			this->grid1->RowCount = 20;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"numeros";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(294, 399);
			this->Controls->Add(this->grid1);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->btndesapilar);
			this->Controls->Add(this->btnapilar);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void btnapilar_Click(System::Object^  sender, System::EventArgs^  e) {
             
		     int I;
             I= Convert::ToInt32(textBox1->Text);
			 if (A.lleno())
			 MessageBox::Show("Pila llena");
			 else 
			 {A.apilar (I);
			 grid1->Rows[tam++]->Cells[0]->Value=I;}
			 }
private: System::Void btndesapilar_Click(System::Object^  sender, System::EventArgs^  e) {

			 int I;
             if(A.vacio())
	         MessageBox::Show("Pila vacia");
			 else 
			 {I=A.desapilar();
			 textBox2->Text=I.ToString();
			 grid1->Rows->RemoveAt(--tam);}
		 }
};
}

