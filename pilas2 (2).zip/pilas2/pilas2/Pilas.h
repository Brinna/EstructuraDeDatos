#pragma once
#define N 20
class Pilas
{private:
int cima;
int V[N];
public:
	Pilas(void);
	void apilar (int x);
	int desapilar();
	bool vacio();
	bool lleno();
};

