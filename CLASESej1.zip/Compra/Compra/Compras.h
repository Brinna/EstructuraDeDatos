#pragma once
#include <string>
using namespace std;

class Compras
{
private:
	string producto;
	int codigo;
	int precio;
public:
	Compras(void);
	string Get_producto();
	void Set_producto(string prod);
	int Get_codigo();
	void Set_codigo(int cod);
	void Total(int descuento);
	int Get_precio();
	void Set_precio(int pre);
	int pago();
	
};

