#include "StdAfx.h"
#include "Compras.h"
#include <string>

using namespace std; 

Compras::Compras(void)
{
}
string Compras::Get_producto()
{
	return producto;\
}
int Compras::pago()
{
	return precio;
}
void Compras:: Set_producto(string prod)
{
	producto= prod;
}
int Compras::Get_codigo()
{
		return codigo;
}
void Compras::Set_codigo(int cod)
{
		codigo=cod;
}
int Compras::Get_precio()
{
	return precio;
}
void Compras::Set_precio(int pre)
{
	precio=pre;
}
void Compras::Total(int descuento)
{
	precio= precio-descuento;
}
