
//clase Nodo 

#pragma once 
#include "Dato.h"
#define MAX 50

class Nodo { public: 
    Dato dato[MAX];   //crea vector

    Nodo *puntero;  //esta formado por dato
 
     
    Nodo(){ //Constructor de la clase
        puntero = NULL; 
    }
}; 
//estatico  sin puntero :usar  define , definir un vector