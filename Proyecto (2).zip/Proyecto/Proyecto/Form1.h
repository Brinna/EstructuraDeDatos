#pragma once
#include "Persona.h"
#include "Nodo.h"
#include "Lista.h"
#include <iostream>
#include <string>
#include <time.h>
#include <msclr\marshal_cppstd.h>
namespace Proyecto {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	Persona B;
	Nodo A;
	Lista C;
	int pos=0;
	int tam=1;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnProducto;
	protected: 

	protected: 

	protected: 

	private: System::Windows::Forms::TextBox^  txtSaldo2;
	private: System::Windows::Forms::TextBox^  txtProductos;


	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtFinal;

	private: System::Windows::Forms::DataGridView^  GridLista;


	private: System::Windows::Forms::DataGridView^  GridProducto;


	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  column3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;

	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  btnEliminar;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Label^  label5;











	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->btnProducto = (gcnew System::Windows::Forms::Button());
			this->txtSaldo2 = (gcnew System::Windows::Forms::TextBox());
			this->txtProductos = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtFinal = (gcnew System::Windows::Forms::TextBox());
			this->GridLista = (gcnew System::Windows::Forms::DataGridView());
			this->Grid = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column5 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->GridProducto = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->btnEliminar = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->GridLista))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->GridProducto))->BeginInit();
			this->SuspendLayout();
			// 
			// btnProducto
			// 
			this->btnProducto->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->btnProducto->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"btnProducto.BackgroundImage")));
			this->btnProducto->Location = System::Drawing::Point(261, 119);
			this->btnProducto->Name = L"btnProducto";
			this->btnProducto->Size = System::Drawing::Size(97, 23);
			this->btnProducto->TabIndex = 1;
			this->btnProducto->Text = L"Ingresar";
			this->btnProducto->UseVisualStyleBackColor = false;
			this->btnProducto->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// txtSaldo2
			// 
			this->txtSaldo2->Location = System::Drawing::Point(139, 63);
			this->txtSaldo2->Name = L"txtSaldo2";
			this->txtSaldo2->Size = System::Drawing::Size(100, 22);
			this->txtSaldo2->TabIndex = 2;
			// 
			// txtProductos
			// 
			this->txtProductos->Location = System::Drawing::Point(139, 119);
			this->txtProductos->Name = L"txtProductos";
			this->txtProductos->Size = System::Drawing::Size(100, 22);
			this->txtProductos->TabIndex = 3;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(12, 63);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(65, 23);
			this->label1->TabIndex = 4;
			this->label1->Text = L"Saldo";
			this->label1->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 119);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(111, 23);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Productos";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Snow;
			this->label3->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label3->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(26, 475);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(191, 25);
			this->label3->TabIndex = 6;
			this->label3->Text = L"su nuevo saldo es:";
			// 
			// txtFinal
			// 
			this->txtFinal->Location = System::Drawing::Point(247, 475);
			this->txtFinal->Name = L"txtFinal";
			this->txtFinal->Size = System::Drawing::Size(100, 22);
			this->txtFinal->TabIndex = 7;
			// 
			// GridLista
			// 
			this->GridLista->BackgroundColor = System::Drawing::Color::SandyBrown;
			this->GridLista->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->GridLista->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Grid, this->Column5});
			this->GridLista->Location = System::Drawing::Point(12, 174);
			this->GridLista->Name = L"GridLista";
			this->GridLista->RowTemplate->Height = 24;
			this->GridLista->Size = System::Drawing::Size(271, 217);
			this->GridLista->TabIndex = 8;
			// 
			// Grid
			// 
			this->Grid->HeaderText = L"Mi lista de compras:";
			this->Grid->Name = L"Grid";
			// 
			// Column5
			// 
			this->Column5->HeaderText = L"Precio";
			this->Column5->Name = L"Column5";
			// 
			// GridProducto
			// 
			this->GridProducto->BackgroundColor = System::Drawing::Color::LightCoral;
			this->GridProducto->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->GridProducto->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {this->Column1, 
				this->Column2, this->column3, this->Column4});
			this->GridProducto->Location = System::Drawing::Point(489, 39);
			this->GridProducto->Name = L"GridProducto";
			this->GridProducto->RowTemplate->Height = 24;
			this->GridProducto->Size = System::Drawing::Size(622, 169);
			this->GridProducto->TabIndex = 9;
			this->GridProducto->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dataGridView2_CellContentClick);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Producto";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Supermercado 1";
			this->Column2->Name = L"Column2";
			// 
			// column3
			// 
			this->column3->HeaderText = L"Supermercado 2";
			this->column3->Name = L"column3";
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"Supermercado 3";
			this->Column4->Name = L"Column4";
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::Snow;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button2->Location = System::Drawing::Point(656, 265);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(37, 38);
			this->button2->TabIndex = 11;
			this->button2->Text = L"1";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// btnEliminar
			// 
			this->btnEliminar->BackColor = System::Drawing::Color::Snow;
			this->btnEliminar->Location = System::Drawing::Point(311, 293);
			this->btnEliminar->Name = L"btnEliminar";
			this->btnEliminar->Size = System::Drawing::Size(97, 23);
			this->btnEliminar->TabIndex = 12;
			this->btnEliminar->Text = L"Eliminar";
			this->btnEliminar->UseVisualStyleBackColor = false;
			this->btnEliminar->Click += gcnew System::EventHandler(this, &Form1::btnEliminar_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(496, 211);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(211, 51);
			this->label4->TabIndex = 13;
			this->label4->Text = L"Porfavor seleccione una opcion:\r\n\r\n\r\n";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Snow;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(756, 265);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(37, 38);
			this->button1->TabIndex = 14;
			this->button1->Text = L"2";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click_1);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::Snow;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(857, 265);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(37, 38);
			this->button3->TabIndex = 15;
			this->button3->Text = L"3";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::Snow;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button4->Location = System::Drawing::Point(311, 347);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(228, 44);
			this->button4->TabIndex = 16;
			this->button4->Text = L"Calcular nuevo sueldo";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::White;
			this->button5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button5->ForeColor = System::Drawing::Color::Black;
			this->button5->Location = System::Drawing::Point(367, 463);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(218, 34);
			this->button5->TabIndex = 17;
			this->button5->Text = L"confirmar pedido";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Rage Italic", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::Black;
			this->label5->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label5.Image")));
			this->label5->Location = System::Drawing::Point(743, 424);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(293, 76);
			this->label5->TabIndex = 18;
			this->label5->Text = L"TU LISTA";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightSeaGreen;
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->ClientSize = System::Drawing::Size(1211, 753);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->btnEliminar);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->GridProducto);
			this->Controls->Add(this->GridLista);
			this->Controls->Add(this->txtFinal);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtProductos);
			this->Controls->Add(this->txtSaldo2);
			this->Controls->Add(this->btnProducto);
			this->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->GridLista))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->GridProducto))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
		 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void dataGridView2_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
		 }
private: System::Void listBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
GridLista->RowCount=Max;
string prod;
int n1, n2, n3;
prod=marshal_as<string>(Convert::ToString(txtProductos->Text));

GridProducto->Rows[0]->Cells[0]->Value=marshal_as<String^>(prod);
GridProducto->RowCount=1;

srand(time(0));
n1= rand()%10 +1;
GridProducto->Rows[0]->Cells[1]->Value=System::Convert::ToString(n1);


srand(time(0));
n2= rand()%10 +2;
GridProducto->Rows[0]->Cells[2]->Value=System::Convert::ToString(n2);

srand(time(0));
n3= rand()%10 +3;
GridProducto->Rows[0]->Cells[3]->Value=System::Convert::ToString(n3);		 }


private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
	
int uno;
string product;
uno=System::Convert::ToInt32(GridProducto->Rows[0]->Cells[1]->Value);
product= marshal_as<string>(Convert::ToString(GridProducto->Rows[0]->Cells[0]->Value));
A.Agregar(uno, product);
C.Insertar(A);
GridLista->Rows[pos]->Cells[0]->Value=marshal_as<String^>(product);
GridLista->Rows[pos]->Cells[1]->Value=System::Convert::ToString(uno);
pos++;		 }


private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {

int dos;
string product;
dos=System::Convert::ToInt32(GridProducto->Rows[0]->Cells[2]->Value);
product= marshal_as<string>(Convert::ToString(GridProducto->Rows[0]->Cells[0]->Value));
A.Agregar(dos, product);
C.Insertar(A);
GridLista->Rows[pos]->Cells[0]->Value=marshal_as<String^>(product);
GridLista->Rows[pos]->Cells[1]->Value=System::Convert::ToString(dos);	
pos++;  }


private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {

int tres;
string product;
tres=System::Convert::ToInt32(GridProducto->Rows[0]->Cells[3]->Value);
product= marshal_as<string>(Convert::ToString(GridProducto->Rows[0]->Cells[0]->Value));
A.Agregar(tres, product);
C.Insertar(A);
GridLista->Rows[pos]->Cells[0]->Value=marshal_as<String^>(product);
GridLista->Rows[pos]->Cells[1]->Value=System::Convert::ToString(tres);
pos++;		 }
private: System::Void btnEliminar_Click(System::Object^  sender, System::EventArgs^  e) {
		Nodo elem;
		C.eliminar(elem);
		GridLista->Rows->RemoveAt(--pos);

		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
int s=0;
int elem;
int NS;
for(int i=0;i<pos;i++)
{elem=System::Convert::ToInt32(GridLista->Rows[i]->Cells[1]->Value);
s=s+elem;
}
NS=B.Get_Saldo()-s;
txtFinal->Text=Convert::ToString(NS);

		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
			 MessageBox::Show ("PEDIDO CONFIRMADO");
		 }
};
}

 