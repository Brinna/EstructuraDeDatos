#pragma once
#include "string"

using namespace std;

class Nodo
{private:
	int  Precio;
	string Producto;
public:
	Nodo(void);
	void Agregar(int pre, string prod);
	double Get_Precio();
	string Get_Producto();
};

