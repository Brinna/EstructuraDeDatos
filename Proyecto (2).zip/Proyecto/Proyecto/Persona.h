#pragma once
#define Max 50
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;


class Persona
{protected:
string Nombre;
double Saldo;
int CI;

public:
	Persona(void);
	void Set_Nombre (string nom);
	string Get_Nombre();
	void Set_Saldo (double sal);
	double Get_Saldo();
	void Set_CI (int c);
	int Get_CI();
	
};

