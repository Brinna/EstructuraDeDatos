#include "StdAfx.h"
#include "Nodo.h"


Nodo::Nodo(void)
{Precio=0;
Producto= ' ';
}

void Nodo::Agregar(int pre, string prod)
{Precio=pre;
Producto=prod;
}

double Nodo::Get_Precio()
{return Precio;
}


string Nodo::Get_Producto()
{return Producto;
}