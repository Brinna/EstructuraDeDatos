#pragma once
class Pilas

{
   private:
           int pilas[MAX];
           int cima;
        
   public:
		  Pilas(void);
          bool Apilar(TipoDato &elemento);
          bool Desapilar();
          bool CimaPilas(TipoDato &elemento);
          void LimpiarPilas();
          void VerPilas();          
          bool PilasVacia();
          bool Iguales(Pilas p)
	
};

