#include "StdAfx.h"
#include "Pilas.h"


Pilas::Pilas(void)
{cima = -1;  
}


bool Pilas::Apilar(TipoDato &elemento)
{
bool res;
if(cima == MAX-1)
{   cout << "Desbordamiento de Pila (Overflow)" << endl;
  res=false;
}else

     {cima++;
pilas[cima] = elemento;
res = true;
}
return res;


}

bool Pilas::Desapilar()
{
bool res;
if(cima == -1)
{   cerr << "Se esta intentando quitar un elemento de una pila vacia (underflow)" << endl;
  res=false;
}else

     {cima--;
res = true;
}
return res;


}

void Pilas::VerPilas()
{
for(int i=0;i<=cima;i++)
cout << pilas[i] << endl;

}


bool Pilas::CimaPilas(TipoDato &elemento)
{
bool res;
if(PilasVacia())//(cima == -1)
{cerr << "Se esta intentando quitar un elemento de una pila vacia (underflow)" << endl;
res = false;
}else

     { pilas[cima];
cima--;
res = true;
}

return res;


}

bool Pilas::PilasVacia()
{
return cima == -1;
}

void Pilas::LimpiarPilas()
{
cima = -1;
}


bool Pilas::Iguales(Pilas p)
{
TipoDato a , b;
TipoDato array[MAX];

bool iguales=false;

int i=cima;
while (p.CimaPilas(b) && array[i--]==b)
{
    p.Desapilar();
}
if(i<0 && p.PilasVacia())
iguales=true;

return iguales;
}