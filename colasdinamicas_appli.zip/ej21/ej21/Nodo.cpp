#include "StdAfx.h"
#include "Nodo.h"


Nodo::Nodo(void)
{//Constructor de la clase
        puntero = NULL; 
   
}


Nodo::~Nodo(void)
{
}
