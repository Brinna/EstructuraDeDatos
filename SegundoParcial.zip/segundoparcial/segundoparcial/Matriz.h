#pragma once
#define N 5
class Matriz
{private:
int M[N][N];
int Fila;
int Columna;
public:
	Matriz(void);
	void Set_fila(int x);
	void Set_columna (int y);
	int Get_fila();
	int Get_columna();
	void insertar (int e,int x, int y);
	int mostrar();
	int factorial();
};

