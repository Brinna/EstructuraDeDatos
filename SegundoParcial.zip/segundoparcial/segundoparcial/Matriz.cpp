#include "StdAfx.h"
#include "Matriz.h"


Matriz::Matriz(void)
{Fila=0;
Columna=0;
}

void Matriz::Set_fila(int x)
{Fila=x;
}

void Matriz::Set_columna (int y)
{Columna=y;
}

int Matriz::Get_fila()
{return Fila;
}
int Matriz::Get_columna()
{return Columna;
}
void Matriz::insertar (int e,int x, int y)
{M[x][y]=e;
}
